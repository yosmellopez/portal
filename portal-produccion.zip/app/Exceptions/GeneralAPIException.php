<?php

namespace App\Exceptions;

use Exception;

class GeneralAPIException extends Exception
{
    public function render()
    {
        // ...
    }
}
